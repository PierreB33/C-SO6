using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace TD1
{
    class Revue : Document
    {
        private string Mois;
        private int Annee;

        public Revue(string nenregistrement, string titre, int nbpages, string editeur, string Mois, int Annee) : base(nenregistrement, titre, nbpages, editeur)
        {
            this.Mois = Mois;
            this.Annee = Annee;
        }
        
    }
}