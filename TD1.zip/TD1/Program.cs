﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TD1
{
    class Document
    {
        private int nenregistrement;
        private string titre;
        private int nbpages;
        private string editeur;

        public Document(int nenregistrement, string titre, int nbpages, string editeur)
        {
            this.nenregistrement = nenregistrement;
            this.titre = titre;
            this.nbpages = nbpages;
            this.editeur = editeur;
        }
        public string ToString()
        {
            return ("Le numéro d'enreistrement du document " + titre + " est " + nenregistrement + "son éditeur est " + editeur + " et il fait " + nbpages + " pages.");
        }
    }
}
