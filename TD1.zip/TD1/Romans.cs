using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace TD1
{
    class Roman : Document
    {
        string prix;
        public Roman(int nenregistrement,string titre,int nbpages,string editeur,string prix) : base (nenregistrement,titre,nbpages,editeur)
        {
            this.prix = prix;
        }
    }
}