using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace TD1
{
    class Livre : Document
    {
        private string auteur;

        public Livre(int nenregistrement,string titre,int nbpages,string editeur,string auteur) : base(nenregistrement,titre,nbpages,editeur)
        {
            this.auteur = auteur;
        }
    }
}