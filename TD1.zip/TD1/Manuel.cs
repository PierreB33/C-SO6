using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace TD1
{
    class Manuel : Document
    {
       
        private int niveauscolaire;

        public Manuel(int nenregistrement, string titre,int nbpages,string editeur,int niveauscolaire) : base(nenregistrement,titre,nbpages,editeur)
        {
            this.niveauscolaire = niveauscolaire;
        }
    }
}