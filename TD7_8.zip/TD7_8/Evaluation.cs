﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TD7_8
{
    internal class Evaluation
    {
        private double noteexam;
        private double[] notescc;

        public Evaluation(double noteexam, double[] notescc)
        {
            this.noteexam = noteexam;
            this.notescc = notescc;
        }
        public double CalculNoteFinale1()
        {
            double somme = noteexam;
            double moyenne = 0;
            foreach(var note in notescc)
            {
                somme += note;
            }
            moyenne = somme / notescc.Length + 1;
            return moyenne;

        }
        public double CalculNoteFinale2()
        {
            double somme = noteexam * 0.6;
            double moyenne = 0;
            double sommecc = 0;
            foreach(var note in notescc)
            {
                sommecc += note;
            }
            sommecc = sommecc * 0.4;
            somme += sommecc;
            moyenne = somme / notescc.Length + 1;
            return moyenne;             
        }
        public double CalculNoteFinale3()
        {
            double valeurasuppr = 0;
            double occurrences = notescc.Count(v => v==valeurasuppr);
            if(occurrences==0)
            {
                Console.WriteLine("La valeur à supprimer n'existe pas dans le tableau");
                return 0;
            }
            else
            {
                double[] newnotescc = notescc.Where(v => v != valeurasuppr).ToArray();
                notescc = newnotescc;
            }
            double somme = noteexam * 0.6;
            double sommecc = notescc.Sum() * 0.4;
            double moyenne = (somme + sommecc) / (notescc.Length + 1);
            return moyenne;
        }

        public override string ToString()
        {
            string str = "Note à l'examen : " + noteexam +"notes aux : ";
            for(int i=0;i<notescc.Length;i++)
            {
                str += "CC" + (i + 1)+" " + notescc[i] +" ";
            }
            return str;
        }
    }
}
