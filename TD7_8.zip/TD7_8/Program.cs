﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TD7_8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Choisis un exercice");
            int Exercice = Convert.ToInt32(Console.ReadLine());
            switch (Exercice)
            {
                case 1:
                    Animal_Domestique animal1 = new Animal_Domestique("Pizza", "Pizzou", "2020-10-10", 7);
                    Animal_Domestique animal2 = new Animal_Domestique("Polly", "Paulette", "2020-10-10", 7);
                    Animal_Domestique animal3 = new Animal_Domestique("Elinor", "eli", "2003-12-05", 47);
                    List<Animal_Domestique> listeanimaux = new List<Animal_Domestique>();
                    listeanimaux.Add(animal1);
                    listeanimaux.Add(animal2);
                    listeanimaux.Add(animal3);

                    /* Question 1.1 */
                    List<Animal_Domestique> Chiensplus10 = listeanimaux.FindAll(animal => animal.Poids > 10);
                    foreach (var animal in Chiensplus10)
                    {
                        Console.WriteLine(animal.ToString());
                    }
                    Console.WriteLine();

                    /* Question 1.2 */
                    List<Animal_Domestique> Chienspseudopart = listeanimaux.FindAll(animal => animal.Pseudo == "eli");
                    foreach (var animal in Chienspseudopart)
                    {
                        Console.WriteLine(animal.ToString());
                    }
                    Console.WriteLine();

                    /* Question 1.3 */
                    foreach (var animal in listeanimaux)
                    {
                        animal.Poids = animal.Poids / 0.4536;
                    }
                    Console.WriteLine();
                    foreach (var animal in listeanimaux)
                    {
                        Console.WriteLine(animal.ToString());
                    }

                    /* Question 1.4 */
                    listeanimaux.Sort((a, b) => a.Poids.CompareTo(b.Poids));
                    Console.WriteLine("Animaux triés par poids :");
                    foreach (var animal in listeanimaux)
                    {
                        Console.WriteLine(animal.ToString());
                    }
                    break;
                
                case 2:
                    /* Question 2.1 */
                    Evaluation eleve1 = new Evaluation(16.5,new double[] { 0, 12, 15, 18 });
                    Evaluation eleve2 = new Evaluation(12.5, new double[] { 11, 15, 15 });
                    Evaluation eleve3 = new Evaluation(18, new double[] { 17, 10, 18 });
                    Evaluation eleve4 = new Evaluation(9.5, new double[] { 6, 13, 8 });

                    Console.WriteLine(eleve1.ToString());
                    Console.WriteLine("Méthode 1 : "+ eleve1.CalculNoteFinale1());
                    Console.WriteLine("Méthode 2 : " + eleve1.CalculNoteFinale2());
                    Console.WriteLine("Méthode 3 : " + eleve1.CalculNoteFinale3());
                    break;
                
                default:
                    Console.WriteLine("Cet exercice n'existe pas");
                    break;
                
            }
 
        }
    }
}


