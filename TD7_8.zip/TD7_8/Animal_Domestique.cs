﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TD7_8
{
    internal class Animal_Domestique
    {
        private string nom;
        private string pseudo;
        private DateTime date_naissance;
        private double poids;

        public Animal_Domestique(string nom,string pseudo, string date_naissance, double poids)
        {
            this.nom = nom;
            this.pseudo = pseudo;
            this.date_naissance = DateTime.Parse(date_naissance);
            this.poids = poids;
        }
        public double Poids
        {
            get { return this.poids; }
            set { this.poids = value; }
        }
        public string Pseudo
        {
            get { return this.pseudo; }
            set { this.pseudo = value; }
        }
        public override string ToString()
        {
            return "L'animal : " + nom + " né le " + date_naissance + " qui pèse " + poids;
        }


    }
}
