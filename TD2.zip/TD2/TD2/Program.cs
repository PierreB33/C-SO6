﻿using System;
using System.Reflection.Metadata;
using System.Collections.Generic;
using TD2;
using System.Globalization;
using System.ComponentModel;

namespace TD2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Exercice1_1();
            //Exercice1_2();
            //Exercice1_3();
            //Exercice2();
            Exercice3();

            static void Exercice1_1()
            {
                Console.WriteLine("Veuillez entrer des mots un par un : ");
                string mot = "";
                List<string> phrase = new List<string>();
                while (mot != ".")
                {
                    mot = Console.ReadLine();
                    if (mot == ".") 
                    { 
                        break; 
                    }
                    phrase.Add(mot);
                }
                phrase[phrase.Count - 1] += ".";

                for (int i = 0; i < phrase.Count; i++) 
                { 
                    Console.Write(phrase[i] + " "); 
                }
            }

            static void Exercice1_2()
            {
                Console.WriteLine("Veuillez entrer des mots un par un : ");
                string mot = "";
                Stack<string> phrase = new Stack<string>();
                while (mot != ".")
                {
                    mot = Console.ReadLine();
                    phrase.Push(mot);
                }

                List<string> phrase2 = new List<string>(phrase);
                phrase2.Reverse();
                phrase2.RemoveAt(phrase2.Count-1); 
                phrase2[phrase2.Count - 1] += ".";
                for (int i = 0; i < phrase2.Count; i++)
                {
                    Console.Write(phrase2[i] + " ");
                }
            }

            static void Exercice1_3()
            {
                Console.WriteLine("Veuillez entrer des mots un par un : ");
                string mot = "";
                Queue<string> phrase = new Queue<string>();
                while (mot != ".")
                {
                    mot = Console.ReadLine();
                    phrase.Enqueue(mot);
                }       

                while(phrase.Count > 0)
                {
                    Console.Write(phrase.Dequeue() + " ");
                }
            }

            static void Exercice2()
            {

                ListeChainee<int> a = new ListeChainee<int>();
                a.AddHead(5);
                a.AddHead(6);
                a.AddQueue(7);
                a.Afficher();
                a.Insert(4, 1);
                a.Afficher();
                ListeChainee<string> a1 = new ListeChainee<string>();
                a1.AddHead("5");
                a1.AddHead("6");
                a1.AddQueue("7");
                a1.Afficher();
                a1.Insert("4", 1);
                a1.Afficher();

            }

            static void Exercice3()
            {
                Entreprise entreprise = new Entreprise("entreprise", "adresse");
                entreprise.ListeSalariés("salaries.csv");

                entreprise.Interface();
                
            }
        }
    }
}