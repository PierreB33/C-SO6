﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TD2
{
    internal class Prestataire : Personne
    {
        protected string nom_entreprise;
        protected string domaine;

        public Prestataire(string nom, string prenom, string email, string adresse, string nom_entreprise, string domaine) : base(nom, prenom, email, adresse)
        {
            this.nom_entreprise = nom_entreprise;
            this.domaine = domaine;
        }

        public string Nom_Entreprise
        {
            get { return nom_entreprise; }
            set { nom_entreprise = value; }
        }

        public string Domaine
        {
            get { return domaine; }
            set { domaine = value; }
        }

        public override string ToString()
        {
            return (base.ToString() + "\nNom de l'entreprise : " + nom_entreprise + "\nDomaine : " + domaine);
        }
    }
}
