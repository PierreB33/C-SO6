﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TD2
{
    public class ListeChainee<T>
    {
        public class Noeud
        {
            public T Valeur { get; set; }
            public Noeud Suivant { get; set; }

            public Noeud(T valeur)
            {
                Valeur = valeur;
                Suivant = null;
            }
        }

        private Noeud tete;

        public Noeud Tete
        {
            get { return tete; }
            set { tete = value; }
        }   

        // Constructeur
        public ListeChainee()
        {
            tete = null;
        }

        public void AddQueue(T valeur)
        {
            if (tete == null)
            {
                tete = new Noeud(valeur);
            }
            else
            {
                Noeud courant = tete;
                while (courant.Suivant != null)
                {
                    courant = courant.Suivant;
                }
                courant.Suivant = new Noeud(valeur);
            }
        }

        public void AddHead(T valeur)
        {
            Noeud nouveauNoeud = new Noeud(valeur);
            nouveauNoeud.Suivant = tete;
            tete = nouveauNoeud;
        }

        public void Insert(T valeur, int index)
        {
            if (index < 0 || index > Taille())
            {
                throw new ArgumentOutOfRangeException("index", "Index hors limites");
            }

            if (index == 0)
            {
                AddHead(valeur);
            }
            else
            {
                Noeud nouveauNoeud = new Noeud(valeur);
                Noeud precedant = ObtenirNoeud(index - 1);
                nouveauNoeud.Suivant = precedant.Suivant;
                precedant.Suivant = nouveauNoeud;
            }
        }

        private Noeud ObtenirNoeud(int index)
        {
            Noeud courant = tete;
            for (int i = 0; i < index; i++)
            {
                courant = courant.Suivant;
            }
            return courant;
        }

        public int Taille()
        {
            int count = 0;
            Noeud courant = tete;
            while (courant != null)
            {
                count++;
                courant = courant.Suivant;
            }
            return count;
        }

        public void Afficher()
        {
            Noeud courant = tete;

            Console.Write("ListeChainee: ");
            while (courant != null)
            {
                Console.Write(courant.Valeur + " ");
                courant = courant.Suivant;
            }
            Console.WriteLine();
        }

        public void Remove(T valeur)
        {
            if (tete == null)
            {
                throw new InvalidOperationException("Liste vide");
            }

            if (tete.Valeur.Equals(valeur))
            {
                tete = tete.Suivant;
            }
            else
            {
                Noeud courant = tete;
                while (courant.Suivant != null)
                {
                    if (courant.Suivant.Valeur.Equals(valeur))
                    {
                        courant.Suivant = courant.Suivant.Suivant;
                        return;
                    }
                    courant = courant.Suivant;
                }
            }
        }

    }

}
