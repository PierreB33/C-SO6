﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TD2
{
    internal class Salarié : Personne
    {
        protected double salaire;
        protected int num_salarié;

        public Salarié(string nom, string prenom, string email, string adresse, double salaire) : base(nom, prenom, email, adresse)
        {
            this.salaire = salaire;
            this.num_salarié = 0;
        }

        public double Salaire
        {
            get { return salaire; }
            set { salaire = value; }
        }

        public int Num_Salarié
        {
            get { return num_salarié; }
            set { num_salarié = value; }
        }

        public override string ToString()
        {
            return base.ToString() + "\nSalaire : " + salaire + "\nNuméro de salarié : " + num_salarié;
        }

        

        
    }
}
