﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TD2
{
    internal class Entreprise
    {
        private string nom_entreprise;
        private string adresse;
        private List<Salarié> salariés;
        private List<Prestataire> prestataires;

        public Entreprise(string nom_entreprise, string adresse)
        {
            this.nom_entreprise = nom_entreprise;
            this.adresse = adresse;
            salariés = new List<Salarié>();
            prestataires = new List<Prestataire>();
        }

        public string Nom_Entreprise
        {
            get { return nom_entreprise; }
            set { nom_entreprise = value; }
        }

        public string Adresse
        {
            get { return adresse; }
            set { adresse = value; }
        }

        public List<Salarié> Salariés
        {
            get { return salariés; }
            set { salariés = value; }
        }

        public List<Prestataire> Prestataires
        {
            get { return prestataires; }
            set { prestataires = value; }
        }

        public void AddSalarié(Salarié salarié_ajouté)
        {
            salariés.Add(salarié_ajouté);
            salarié_ajouté.Num_Salarié = salariés.Count;
        }

        public void AddPrestataire(Prestataire prestataire)
        {
            prestataires.Add(prestataire);
        }

        public void RemoveSalarié(Salarié salarié)
        {
            salariés.Remove(salarié);
        }

        public void RemovePrestataire(Prestataire prestataire)
        {
            prestataires.Remove(prestataire);
        }

        public void AfficherSalariés()
        {
            Console.WriteLine("Liste des salariés :");
            foreach (Salarié salarié in salariés)
            {
                Console.WriteLine(salarié.ToString() + "\n");
            }
        }

        public void AfficherPrestataires()
        {
            Console.WriteLine("Liste des prestataires :");
            foreach (Prestataire prestataire in prestataires)
            {
                Console.WriteLine(prestataire.ToString() +"\n");
            }
        }

        public Salarié CreerUnSalarié()
        {
            Console.WriteLine("Veuillez entrer le nom du salarié : ");
            string nom = Console.ReadLine();
            Console.WriteLine("Veuillez entrer le prénom du salarié : ");
            string prenom = Console.ReadLine();
            Console.WriteLine("Veuillez entrer l'email du salarié : ");
            string email = Console.ReadLine();
            Console.WriteLine("Veuillez entrer l'adresse du salarié : ");
            string adresse = Console.ReadLine();
            Console.WriteLine("Veuillez entrer le salaire du salarié : ");
            double salaire = Convert.ToDouble(Console.ReadLine());
            return new Salarié(nom, prenom, email, adresse, salaire);
        }

        public Prestataire CreerUnPrestataire()
        {
            Console.WriteLine("Veuillez entrer le nom du salarié : ");
            string nom = Console.ReadLine();
            Console.WriteLine("Veuillez entrer le prénom du salarié : ");
            string prenom = Console.ReadLine();
            Console.WriteLine("Veuillez entrer l'email du salarié : ");
            string email = Console.ReadLine();
            Console.WriteLine("Veuillez entrer l'adresse du salarié : ");
            string adresse = Console.ReadLine();
            Console.WriteLine("Veuillez entrer le nom de l'entreprise : ");
            string nom_entreprise = Console.ReadLine();
            Console.WriteLine("Veuillez entrer le domaine : ");
            string domaine = Console.ReadLine();
            return new Prestataire(nom, prenom, email, adresse, nom_entreprise, domaine);
        }

        public void Interface()
        {
            Console.WriteLine("--- INTERFACE ENTREPRISE ---");
            Console.WriteLine("\nQue souhaitez-vous faire ?\n \n1)Interface salarié \n2)Interface prestataire \n3)Quitter");
            int choix = Convert.ToInt32(Console.ReadLine());
            switch (choix)
            {
                case 1:
                    InterfaceSalarié();
                    break;
                case 2:
                    InterfacePrestataire();
                    break;
                case 3:
                    break;
                default:
                    Console.WriteLine("Choix invalide");
                    break;
            }
        }

        public void InterfaceSalarié()
        {
            Console.WriteLine("--- INTERFACE SALARIÉ ---");
            Console.WriteLine("\nQue souhaitez-vous faire ?\n \n1)Recruter un salarié \n2)Licencier un salarié \n3)Modifier les informations d'un salarié \n4)Afficher la liste des salariés \n5)Sauvgarder la liste de salariés dans un fichier csv \n6)Quitter");
            int choix = Convert.ToInt32(Console.ReadLine());
            switch (choix)
            {
                case 1:
                    AddSalarié(CreerUnSalarié());
                    Interface();
                    break;
                case 2:
                    AfficherSalariés();
                    Console.WriteLine("\nVeuillez entrer le numéro du salarié à licencier : ");
                    int num = Convert.ToInt32(Console.ReadLine());
                    bool found = false;
                    for(int i = 0; i < salariés.Count; i++)
                    {
                        Console.WriteLine(salariés[i].Num_Salarié);
                        if (num == salariés[i].Num_Salarié)
                        {
                            Console.WriteLine("Le salarié " + salariés[i].Nom + " " + salariés[i].Prenom + " a été licencié");
                            RemoveSalarié(salariés[i]);
                            found = true;
                        }
                    }
                    if(found =! true)
                    {
                        Console.WriteLine("Salarié non trouvé");
                    }
                    Console.WriteLine();
                    InterfaceSalarié();
                    break;
                case 3:
                    ModifierSalarié();
                    Console.WriteLine();
                    InterfaceSalarié();
                    break;
                case 4:
                    AfficherSalariés();
                    Console.WriteLine();
                    InterfaceSalarié();
                    break;
                case 5:
                    CreerFichierSalariés("salaries.csv");
                    Console.WriteLine();
                    InterfaceSalarié();
                    break;
                case 6:
                    Interface();
                    break;
                default:
                    Console.WriteLine("Choix invalide");
                    InterfaceSalarié();
                    break;
            }
        }

        public void InterfacePrestataire()
        {
            Console.WriteLine("--- INTERFACE PRESTATAIRE ---");
            Console.WriteLine("\nQue souhaitez-vous faire ?\n \n1)Ajouter un prestataire \n2)Supprimer un prestataire \n3)Modifier les informations d'un prestataire \n4)Afficher la liste des prestataires \n5)Sauvgarder la liste de prestataires dans un fichier csv \n6)Quitter");
            int choix = Convert.ToInt32(Console.ReadLine());
            switch (choix)
            {
                case 1:
                    AddPrestataire(CreerUnPrestataire());
                    break;
                case 2:
                    AfficherPrestataires();
                    Console.WriteLine("\nVeuillez entrer le nom de l'entreprise du prestataire à supprimer : ");
                    string nom_entreprise = Console.ReadLine();
                    bool found = false;
                    for (int i = 0; i < prestataires.Count; i++)
                    {
                        if (nom_entreprise == prestataires[i].Nom_Entreprise)
                        {
                            RemovePrestataire(prestataires[i]);
                            found = true;
                        }
                    }
                    if (found = !true)
                    {
                        Console.WriteLine("Prestataire non trouvé");
                    }
                    Console.WriteLine();
                    InterfacePrestataire();
                    break;
                case 3:
                    ModifierPrestataire();
                    Console.WriteLine();
                    InterfacePrestataire();
                    break;
                case 4:
                    AfficherPrestataires();
                    Console.WriteLine();
                    InterfacePrestataire();
                    break;
                case 5:
                    CreerFichierPrestataires("prestataires.csv");
                    Console.WriteLine();
                    InterfacePrestataire();
                    break;
                case 6:
                    Console.WriteLine();
                    Interface();
                    break;
                default:
                    Console.WriteLine("Choix invalide");
                    Console.WriteLine();
                    InterfacePrestataire();
                    break;
            }
        }

        public void ModifierSalarié()
        {
            Console.WriteLine("Veuillez entrer le numéro du salarié à modifier : ");
            int num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Que souhaitez -vous modifier ? \n1)nom \n2)prénom  \n3)email \n4)adresse \n5)salaire");
            int choix = Convert.ToInt32(Console.ReadLine());
            switch (choix)
            {
                case 1:
                    Console.WriteLine("Veuillez entrer le nouveau nom : ");
                    salariés[num - 1].Nom = Console.ReadLine();
                    break;
                case 2:
                    Console.WriteLine("Veuillez entrer le nouveau prénom : ");
                    salariés[num - 1].Prenom = Console.ReadLine();
                    break;
                case 3:
                    Console.WriteLine("Veuillez entrer le nouvel email : ");
                    salariés[num - 1].Email = Console.ReadLine();
                    break;
                case 4:
                    Console.WriteLine("Veuillez entrer la nouvelle adresse : ");
                    salariés[num - 1].Adresse = Console.ReadLine();
                    break;
                case 5:
                    Console.WriteLine("Veuillez entrer le nouveau salaire : ");
                    salariés[num - 1].Salaire = Convert.ToDouble(Console.ReadLine());
                    break;
                default:
                    Console.WriteLine("Choix invalide");
                    break;
            }   
        }

        public void ModifierPrestataire()
        {
            bool find = false;
            int num_prestataire = 0;
            do
            {
                Console.WriteLine("Veuillez entrer le nom de l'entreprise du prestataire à modifier :");
                string nom_entreprise = Console.ReadLine();

                for (int i = 0; i < prestataires.Count; i++)
                {
                    if (prestataires[i].Nom_Entreprise == nom_entreprise)
                    {
                        num_prestataire = i;
                        find = true;
                        break;
                    }

                } 
            } while (find = !true);

            Console.WriteLine("Que souhaitez -vous modifier ? \n1)nom \n2)prénom  \n3)email \n4)adresse \n5)nom de l'entreprise \n6)domaine");
            int choix = Convert.ToInt32(Console.ReadLine());
            switch (choix)
            {
                case 1:
                    Console.WriteLine("Veuillez entrer le nouveau nom : ");
                    string nom = Console.ReadLine();
                    prestataires[num_prestataire].Nom = nom;
                    break;
                case 2:
                    Console.WriteLine("Veuillez entrer le nouveau prénom : ");
                    string prenom = Console.ReadLine();
                    prestataires[num_prestataire].Prenom = prenom;
                    break;
                case 3:
                    Console.WriteLine("Veuillez entrer le nouvel email : ");
                    string email = Console.ReadLine();
                    prestataires[num_prestataire].Email = email;
                    break;
                case 4:
                    Console.WriteLine("Veuillez entrer la nouvelle adresse : ");
                    string adresse = Console.ReadLine();
                    prestataires[num_prestataire].Adresse = adresse;
                    break;
                case 5:
                    Console.WriteLine("Veuillez entrer le nouveau nom de l'entreprise : ");
                    string nom_entreprise = Console.ReadLine();
                    prestataires[num_prestataire].Nom_Entreprise = nom_entreprise;
                    break;
                case 6:
                    Console.WriteLine("Veuillez entrer le nouveau domaine : ");
                    string domaine = Console.ReadLine();
                    prestataires[num_prestataire].Nom_Entreprise = domaine;
                    break;
                default:
                    Console.WriteLine("Choix invalide");
                    break;
            }
        }

        public void ListeSalariés(string filepath)
        {
            var lines = File.ReadAllLines(filepath);
            for (int i = 0; i < lines.Count(); i++)
            {
                var values = lines[i].Split(',');
                Salarié new_salarié = new Salarié(values[0], values[1], values[2], values[3], Convert.ToDouble(values[4]));
                AddSalarié(new_salarié);
            }
        }

        public void ListePrestataires(string filepath)
        {
            var lines = File.ReadAllLines(filepath);
            for (int i = 0; i < lines.Count(); i++)
            {
                var values = lines[i].Split(',');
                Prestataire new_prestataire = new Prestataire(values[0], values[1], values[2], values[3], values[4], values[5]);
                AddPrestataire(new_prestataire);
            }
        }

        public void CreerFichierSalariés(string filepath)
        {
            List<string> lignes = new List<string>();
            foreach (Salarié salarié in salariés)
            {
                lignes.Add(salarié.Nom + "," + salarié.Prenom + "," + salarié.Email + "," + salarié.Adresse + "," + salarié.Salaire + "," + salarié.Num_Salarié);
            }
            File.WriteAllLines(filepath, lignes);
        }

        public void CreerFichierPrestataires(string filepath)
        {
            List<string> lignes = new List<string>();
            foreach (Prestataire prestataire in prestataires)
            {
                lignes.Add(prestataire.Nom + "," + prestataire.Prenom + "," + prestataire.Email + "," + prestataire.Adresse + "," + prestataire.Nom_Entreprise + "," + prestataire.Domaine);
            }
            File.WriteAllLines(filepath, lignes);
        }

    }
}
